/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package treelab;

import DataStructures.*;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author levicarpenter66
 */
public class LinkedBinaryTreeTest {
    LinkedBinaryTree instance;
    LinkedBinaryTree instance1;
    LinkedBinaryTree instance2;
    
    public LinkedBinaryTreeTest() throws EmptyCollectionException {
        LinkedBinaryTree instance = new LinkedBinaryTree();
        LinkedBinaryTree instance1 = new LinkedBinaryTree(new BTNode<>(2));
        LinkedBinaryTree instance2 = new LinkedBinaryTree(new BTNode<>(8));
        
        instance1.getRootNode().setLeftChild(new BTNode<>(1));
        instance1.getRootNode().setRightChild(new BTNode<>(3));
        
        instance2.getRootNode().setLeftChild(new BTNode<>(6));
        instance2.getRootNode().getLeftChild().setLeftChild(new BTNode<>(12));
        instance2.getRootNode().getLeftChild().getLeftChild().setRightChild(new BTNode<>(2));
        instance2.getRootNode().setRightChild(new BTNode<>(14));
        instance2.getRootNode().getRightChild().setLeftChild(new BTNode<>(3));
        instance2.getRootNode().getRightChild().setRightChild(new BTNode<>(9));
        instance2.getRootNode().getRightChild().getRightChild().setLeftChild(new BTNode<>(15));
        instance2.getRootNode().getRightChild().getRightChild().getLeftChild().setLeftChild(new BTNode<>(5));
        instance2.getRootNode().getRightChild().getRightChild().getLeftChild().setRightChild(new BTNode<>(4));
        }

    /**
     * Test of inorder method, of class LinkedBinaryTree.
     */
    @Test
    public void testInorder() throws EmptyCollectionException {
        System.out.println("inorder");
        LinkedBinaryTree instance = new LinkedBinaryTree();
        LinkedBinaryTree instance1 = new LinkedBinaryTree(new BTNode<>(2));
        LinkedBinaryTree instance2 = new LinkedBinaryTree(new BTNode<>(8));
        
        instance1.getRootNode().setLeftChild(new BTNode<>(1));
        instance1.getRootNode().setRightChild(new BTNode<>(3));
        
        instance2.getRootNode().setLeftChild(new BTNode<>(6));
        instance2.getRootNode().getLeftChild().setLeftChild(new BTNode<>(12));
        instance2.getRootNode().getLeftChild().getLeftChild().setRightChild(new BTNode<>(2));
        instance2.getRootNode().setRightChild(new BTNode<>(14));
        instance2.getRootNode().getRightChild().setLeftChild(new BTNode<>(3));
        instance2.getRootNode().getRightChild().setRightChild(new BTNode<>(9));
        instance2.getRootNode().getRightChild().getRightChild().setLeftChild(new BTNode<>(15));
        instance2.getRootNode().getRightChild().getRightChild().getLeftChild().setLeftChild(new BTNode<>(5));
        instance2.getRootNode().getRightChild().getRightChild().getLeftChild().setRightChild(new BTNode<>(4));
        
        ArrayList<Integer> traversal = new ArrayList<>();
        assertEquals(traversal, instance.inorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance.inorder());
        
        traversal.add(1);
        traversal.add(2);
        traversal.add(3);
        assertEquals(traversal, instance1.inorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance1.inorder());
        
        traversal.clear();
        traversal.add(12);
        traversal.add(2);
        traversal.add(6);
        traversal.add(8);
        traversal.add(3);
        traversal.add(14);
        traversal.add(5);
        traversal.add(15);
        traversal.add(4);
        traversal.add(9);
        assertEquals(traversal, instance2.inorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance2.inorder());
        
    }

    /**
     * Test of preorder method, of class LinkedBinaryTree.
     */
    @Test
    public void testPreorder() throws EmptyCollectionException {
        System.out.println("preorder");
        LinkedBinaryTree instance = new LinkedBinaryTree();
        LinkedBinaryTree instance1 = new LinkedBinaryTree(new BTNode<>(2));
        LinkedBinaryTree instance2 = new LinkedBinaryTree(new BTNode<>(8));
        
        instance1.getRootNode().setLeftChild(new BTNode<>(1));
        instance1.getRootNode().setRightChild(new BTNode<>(3));
        
        instance2.getRootNode().setLeftChild(new BTNode<>(6));
        instance2.getRootNode().getLeftChild().setLeftChild(new BTNode<>(12));
        instance2.getRootNode().getLeftChild().getLeftChild().setRightChild(new BTNode<>(2));
        instance2.getRootNode().setRightChild(new BTNode<>(14));
        instance2.getRootNode().getRightChild().setLeftChild(new BTNode<>(3));
        instance2.getRootNode().getRightChild().setRightChild(new BTNode<>(9));
        instance2.getRootNode().getRightChild().getRightChild().setLeftChild(new BTNode<>(15));
        instance2.getRootNode().getRightChild().getRightChild().getLeftChild().setLeftChild(new BTNode<>(5));
        instance2.getRootNode().getRightChild().getRightChild().getLeftChild().setRightChild(new BTNode<>(4));
        
        ArrayList<Integer> traversal = new ArrayList<>();
        assertEquals(traversal, instance.preorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance.preorder());
        
        traversal.add(2);
        traversal.add(1);
        traversal.add(3);
        assertEquals(traversal, instance1.preorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance1.preorder());
        
        traversal.clear();
        traversal.add(8);
        traversal.add(6);
        traversal.add(12);
        traversal.add(2);
        traversal.add(14);
        traversal.add(3);
        traversal.add(9);
        traversal.add(15);
        traversal.add(5);
        traversal.add(4);
        assertEquals(traversal, instance2.preorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance2.preorder());
    }

    /**
     * Test of postorder method, of class LinkedBinaryTree.
     */
    @Test
    public void testPostorder() throws EmptyCollectionException {
        System.out.println("postorder");
        LinkedBinaryTree instance = new LinkedBinaryTree();
        LinkedBinaryTree instance1 = new LinkedBinaryTree(new BTNode<>(2));
        LinkedBinaryTree instance2 = new LinkedBinaryTree(new BTNode<>(8));
        
        instance1.getRootNode().setLeftChild(new BTNode<>(1));
        instance1.getRootNode().setRightChild(new BTNode<>(3));
        
        instance2.getRootNode().setLeftChild(new BTNode<>(6));
        instance2.getRootNode().getLeftChild().setLeftChild(new BTNode<>(12));
        instance2.getRootNode().getLeftChild().getLeftChild().setRightChild(new BTNode<>(2));
        instance2.getRootNode().setRightChild(new BTNode<>(14));
        instance2.getRootNode().getRightChild().setLeftChild(new BTNode<>(3));
        instance2.getRootNode().getRightChild().setRightChild(new BTNode<>(9));
        instance2.getRootNode().getRightChild().getRightChild().setLeftChild(new BTNode<>(15));
        instance2.getRootNode().getRightChild().getRightChild().getLeftChild().setLeftChild(new BTNode<>(5));
        instance2.getRootNode().getRightChild().getRightChild().getLeftChild().setRightChild(new BTNode<>(4));
        
        ArrayList<Integer> traversal = new ArrayList<>();
        assertEquals(traversal, instance.postorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance.postorder());
        
        traversal.add(1);
        traversal.add(3);
        traversal.add(2);
        assertEquals(traversal, instance1.postorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance1.postorder());
        
        traversal.clear();
        traversal.add(2);
        traversal.add(12);
        traversal.add(6);
        traversal.add(3);
        traversal.add(5);
        traversal.add(4);
        traversal.add(15);
        traversal.add(9);
        traversal.add(14);
        traversal.add(8);
        assertEquals(traversal, instance2.postorder());
        System.out.println("Expected: " + traversal);
        System.out.println("Actual: " + instance2.postorder());
    }
    
}
