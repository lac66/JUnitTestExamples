package treelab;

import DataStructures.*;
import java.util.ArrayList;

/**
 *
 * @author Dr. B
 */
public class LinkedBinaryTree<T> {
    private BTNode<T> rootNode;
    
    public LinkedBinaryTree() {
        rootNode = null;
    }
    
    public LinkedBinaryTree(BTNode<T> root) {
        rootNode = root;
    }

    public T getRootElement() throws EmptyCollectionException {
        if (rootNode == null) {
            throw new EmptyCollectionException("Tree is empty; no root to return.");
        }
        return rootNode.getElement();
    }
    
    public BTNode<T> getRootNode() throws EmptyCollectionException {
        if (rootNode == null) {
            throw new EmptyCollectionException("Tree is empty; no root to return.");
        }
        return rootNode;
    }
    
    public boolean isEmpty() {
        return rootNode == null;
    }
    
    public ArrayList<T> inorder() {
        ArrayList<T> traversal = new ArrayList<T>();
        
        if (rootNode == null) {
            return traversal;
        }
        
        // traverse left subtree first
        if (rootNode.getLeftChild() != null) {
            LinkedBinaryTree<T> L = new LinkedBinaryTree<>(rootNode.getLeftChild());
            traversal.addAll(L.inorder());
        }
        
        // traverse root node
        traversal.add(rootNode.getElement());
        
        // traverse right subtree last
        if (rootNode.getRightChild() != null) {
            LinkedBinaryTree<T> R = new LinkedBinaryTree<>(rootNode.getRightChild());
            traversal.addAll(R.inorder());
        }
        
        return traversal;
    }
    
    public ArrayList<T> preorder() {
        ArrayList<T> traversal = new ArrayList<T>();
        
        if (rootNode == null) {
            return traversal;
        }
        
        
        // traverse root node
        traversal.add(rootNode.getElement());
        
        
        // traverse left subtree first
        if (rootNode.getLeftChild() != null) {
            LinkedBinaryTree<T> L = new LinkedBinaryTree<>(rootNode.getLeftChild());
            traversal.addAll(L.preorder());
        }
        
        
        // traverse right subtree last
        if (rootNode.getRightChild() != null) {
            LinkedBinaryTree<T> R = new LinkedBinaryTree<>(rootNode.getRightChild());
            traversal.addAll(R.preorder());
        }
        
        return traversal;
    }
    
    public ArrayList<T> postorder() {
        ArrayList<T> traversal = new ArrayList<T>();
        
        if (rootNode == null) {
            return traversal;
        }
        
        // traverse left subtree first
        if (rootNode.getLeftChild() != null) {
            LinkedBinaryTree<T> L = new LinkedBinaryTree<>(rootNode.getLeftChild());
            traversal.addAll(L.postorder());
        }
        
        // traverse right subtree last
        if (rootNode.getRightChild() != null) {
            LinkedBinaryTree<T> R = new LinkedBinaryTree<>(rootNode.getRightChild());
            traversal.addAll(R.postorder());
        }
        
        // traverse root node
        traversal.add(rootNode.getElement());
        
        return traversal;
    }
}
